def function():
    print("this is my import statement working")
    return